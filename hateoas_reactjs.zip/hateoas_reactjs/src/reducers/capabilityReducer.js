const initialState = {
  capabilities: [],
  capability: {},
  links: {}
};

export default function(state = initialState, action) {
  switch (action.type) {
    //GET CAPABILITIES
    //OTHER REDUCER ACTIONS.
    default:
      return state;
  }
}
